package com.cg.sprint.exceptions;
@SuppressWarnings("serial")
public class InvalidTheaterIdException extends Exception
{
	public InvalidTheaterIdException()
	{
		super();
	}
	public InvalidTheaterIdException(String message)
	{
		super(message);
	}
}