package com.cg.sprint.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.cg.sprint.bean.User;
import com.cg.sprint.dao.UserDao;

@Service
public class UserService 
{
	@Autowired
	UserDao udao;
	public void Udao(UserDao udao)
	{
		this.udao=udao;
	}
	@Transactional(readOnly=true)
		public User getUserById(String user_id)
		{
			return udao.findById(user_id).get();
		}
	@Transactional
	public User addUser(User user)
	{
		return udao.save(user);
	}

}
