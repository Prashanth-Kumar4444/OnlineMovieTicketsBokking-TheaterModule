package com.cg.sprint.bean;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import springfox.documentation.swagger2.annotations.EnableSwagger2;
@EnableSwagger2
@Entity
public class Theater
{
	 @Id
	 @NotNull()
	 @Min(value = 70000)
	 @Max(value=90000)
	  @Column(name="theater_id")
	   int theaterId;
	  @Column(name="theater_name")
	   String theaterName;
	  @Column(name="theater_row")
	   int rows;
	  @Column(name="columns")
	   int columns;
	  @Column(name="location")
	   String theaterLocation;
	  @Column(name="manager_name")
	   String managerName;
	  @Column(name="screen")
	   String screen;
	public Theater() 
	{	
		
	}
	public Theater(@NotNull @Min(70000) @Max(90000) int theaterId, String theaterName, int rows, int columns,
			String theaterLocation, String managerName, String screen) {
		super();
		this.theaterId = theaterId;
		this.theaterName = theaterName;
		this.rows = rows;
		this.columns = columns;
		this.theaterLocation = theaterLocation;
		this.managerName = managerName;
		this.screen = screen;
	}
	public int getTheaterId() {
		return theaterId;
	}
	public void setTheaterId(int theaterId) {
		this.theaterId = theaterId;
	}
	public String getTheaterName() {
		return theaterName;
	}
	public void setTheaterName(String theaterName) {
		this.theaterName = theaterName;
	}
	public int getRows() {
		return rows;
	}
	public void setRows(int rows) {
		this.rows = rows;
	}
	public int getColumns() {
		return columns;
	}
	public void setColumns(int columns) {
		this.columns = columns;
	}
	public String getTheaterLocation() {
		return theaterLocation;
	}
	public void setTheaterLocation(String theaterLocation) {
		this.theaterLocation = theaterLocation;
	}
	public String getManagerName() {
		return managerName;
	}
	public void setManagerName(String managerName) {
		this.managerName = managerName;
	}
	public String getScreen() {
		return screen;
	}
	public void setScreen(String screen) {
		this.screen = screen;
	}
}