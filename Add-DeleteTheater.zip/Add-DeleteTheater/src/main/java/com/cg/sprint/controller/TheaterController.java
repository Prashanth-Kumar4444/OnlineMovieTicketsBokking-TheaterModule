package com.cg.sprint.controller;
import java.util.List;
import java.util.Optional;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import com.cg.sprint.bean.Theater;
import com.cg.sprint.exceptions.InvalidTheaterIdException;
import com.cg.sprint.service.TheaterService;
@RestController
public class TheaterController 
{
	@Autowired
	TheaterService theaterService;
	public void setTheaterService(TheaterService theaterService)
	{
		this.theaterService=theaterService;
	}
	//getTheater
		@GetMapping("/getTheater/{theaterId}") 
		   /*public Theater getTheater(@PathVariable int theaterId) throws InvalidTheaterIdException
		   {
			  return theaterService.getTheater(theaterId);
		   }*/
		public ResponseEntity<Optional<Theater>> getTheater(@PathVariable int theaterId)
		{
			Optional<Theater> theater =theaterService.getTheater(theaterId);
			if(theater.isPresent())
				return new ResponseEntity<Optional<Theater>>(theater,HttpStatus.OK);
			return new ResponseEntity<Optional<Theater>>(theater,HttpStatus.NOT_FOUND);
		}
		//GetAllTheaters
		@GetMapping(value="/getTheaters",produces="application/json")
		public List<Theater> getTheater()
		{
			return theaterService.getTheater();
		}
		//postMapping is used for updating and adding
		  @PostMapping(value="/addTheater",consumes="application/json")
		  public ResponseEntity<String> inserTheater(@Valid @RequestBody  Theater theater, BindingResult error)
		  {
			  if(error.hasErrors() || theaterService.insertTheater(theater)==null)
			  {
				  String wrong="Invalid Details";
				  return new ResponseEntity<String>(wrong, HttpStatus.BAD_REQUEST);
			  }
			  else
			  {
				  String message="Theater Details inserted Succesfully";
				  return new ResponseEntity<String>(message,HttpStatus.OK);
			  }
		  }
		//DeleteTheater
		@DeleteMapping("/deleteTheater/{theaterId}")
		   /*public String deleteTheater(@PathVariable int theaterId) throws InvalidTheaterIdException 
		   {
			return theaterService.deleteTheater(theaterId);
		   }*/
		public ResponseEntity<String> deleteTheater(@PathVariable int theaterId)
		{
			try
			{
				theaterService.deleteTheater(theaterId);
				return new ResponseEntity<String>("Deleted Successfully",HttpStatus.OK);
			}
			catch(Exception ex)
			{
				return new ResponseEntity<String>("Deletion failed",HttpStatus.NOT_FOUND);
			}
		}
}